
list = [0,1, 2, 3, 4, 5]
list.reverse()
print(list)

def print_and_return(list):
    print(list[0])
    return list[1]
print (print_and_return([1,2]))

def first_plus_length(list):
    print(list[0-5])
    return len(list)
print(list)[1,2]

def values_greater_than_second(list):
    if len(list)<2:
        return False
    newList = []
    # greaterThan = list[1]
    for val in list:
        if val>list[1]:
            newList.append(val)
    print(len(newList))    
    return newList
print(values_greater_than_second([55,6,2,3,99,78,20,1]))
print(values_greater_than_second([55,0,2,3,99,78,20,1]))
print(values_greater_than_second([1]))
print(values_greater_than_second([]))

my_list = ['2', '3'] 
another_list = [2, 3, 4, 5] 
my_list.extend(another_list) 
print(my_list)